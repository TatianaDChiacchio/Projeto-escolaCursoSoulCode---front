import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Professor } from '../models/professorModel';

@Injectable({
  providedIn: 'root'
})
export class ProfessorService {

  baseUrl: String = 'http://localhost:8080/escola'

  constructor(private http:HttpClient) { }

  buscarProfessoDaTurma(id_turma: string):Observable<Professor[]>{

    //professor-turma/{id_turma}

    const url = `${this.baseUrl}/professor-turma/${id_turma}`
    return this.http.get<Professor[]>(url)

  }

  cadastrarProfessor(id_turma:string,professor:Professor):Observable<Professor>{

    //http://localhost:8080/escola/professor?turma=

    const url = `${this.baseUrl}/professor?turma=${id_turma}`
    return this.http.post<Professor>(url,professor)

  }

  trocarProfesssorDaTurma(professor:Professor,id_professor:string,id_turma:string):Observable<Professor>{
    const url = `${this.baseUrl}/professor/${id_professor}/?turma=${id_turma}`
    return this.http.put<Professor>(url,professor)
  }


}
