import { ActivatedRoute, Router } from '@angular/router';
import { ProfessorService } from './../../servicos/professor.service';
import { Component, OnInit } from '@angular/core';
import { Professor } from 'src/app/models/professorModel';

@Component({
  selector: 'app-professor-da-turma',
  templateUrl: './professor-da-turma.component.html',
  styleUrls: ['./professor-da-turma.component.css']
})
export class ProfessorDaTurmaComponent implements OnInit {

  cadastrado:boolean = false

  professorDaTurma:any = []

  id_turma: any

  professor:Professor ={
    id_professor:'',
    pro_nome:'',
    pro_formacao:'',
    pro_foto:''
  }

  constructor(private professorService:ProfessorService,
              private route:ActivatedRoute,
              private router:Router) { }

  ngOnInit(): void {
    this.id_turma = this.route.snapshot.paramMap.get('id_turma')

    this.buscarProfessordaTurma()
  }



  buscarProfessordaTurma(){
    this.professorService.buscarProfessoDaTurma(this.id_turma).subscribe((resultado) =>{

      if(resultado == undefined){
        alert("Pra essa turma ainda não está definido um professor")
        this.cadastrado = false
      }else{
        this.cadastrado = true
        this.professorDaTurma = resultado;
        console.log(this.professorDaTurma)
      }


    })

  }

  cadastrarProfessor(){
    this.professorService.cadastrarProfessor(this.id_turma,this.professor).subscribe({
    complete: () => { alert("Professor cadastrado com sucesso")
                      this.router.navigate([`turma`])
                    },
    error: () => { alert("Professor não cadastrado")
                      this.router.navigate([`turma`])
                    },
    next: () => { console.log("Professor cadastrado com sucesso")}

    });

  }

  trocarTurma(id_professor:any){
    this.id_turma = prompt("Pra qual turma deseja atribuir o professor?", "id_turma")

    this.professorService.trocarProfesssorDaTurma(this.professorDaTurma,id_professor,this.id_turma).subscribe({
      complete: () => { alert("Professor trocado de turma")
                        this.router.navigate([`turma`])
                      },
      error: () => { alert("Professor não trocado")
                       },
      next: () => { console.log("Professor trocado de turma")}

    });
  }

}
