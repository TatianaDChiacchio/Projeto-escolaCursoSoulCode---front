import { AlunosComTurma } from './../../models/alunosComTurmaModel';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlunoService } from 'src/app/servicos/aluno.service';


@Component({
  selector: 'app-lista-aluno-com-turma',
  templateUrl: './lista-aluno-com-turma.component.html',
  styleUrls: ['./lista-aluno-com-turma.component.css']
})
export class ListaAlunoComTurmaComponent implements OnInit {

  alunosComTurma: AlunosComTurma[] = []
  alunos:any

  constructor(private alunoService: AlunoService,
              private route:ActivatedRoute,
              private router:Router) { }

  ngOnInit(): void {

    this.buscarTodosAlunos()
  }



  buscarTodosAlunos(){
    this.alunoService.buscarTodosAlunos().subscribe(resultado =>{


      this.alunosComTurma = resultado
      console.log(this.alunosComTurma)

    })

  }

}
