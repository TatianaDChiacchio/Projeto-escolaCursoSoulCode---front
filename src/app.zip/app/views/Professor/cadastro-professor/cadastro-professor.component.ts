import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { ProfessorService } from 'src/app/servicos/professor.service';
import { Component, OnInit } from '@angular/core';
import { Professor } from 'src/app/models/ProfessorModel';

@Component({
  selector: 'app-cadastro-professor',
  templateUrl: './cadastro-professor.component.html',
  styleUrls: ['./cadastro-professor.component.css']
})
export class CadastroProfessorComponent implements OnInit {

  idProfessorCadastrado: any
  cadastrado:boolean = false
  foto:any

  professor:Professor ={
    id_professor: '',
    pro_nome:'',
    pro_formacao:'',
    pro_foto:''

  }
  constructor(private professorService:ProfessorService,
              private router:Router,
              private http:HttpClient) { }

  ngOnInit(): void {
  }


  confirmarCadastroAluno(){
    this.professorService.cadastrarProfessor(this.professor).subscribe({
    complete: () => { alert("Professor cadastrado com sucesso")
                      this.professorService.buscarProfessorPeloNome(`${this.professor.pro_nome}`)
                      .subscribe(resultado =>{
                        console.log(resultado.id_professor)
                        this.idProfessorCadastrado = resultado.id_professor
                      })
                      this.cadastrado = true

                    },
    error: () => { alert("Professor não cadastrado")
                      this.router.navigate(['/professor/listaProfessor'])
                    },
    next: () => { console.log("Professor cadastrado com sucesso")}

    });

  }

  inputFileChange(event:any){
    if (event.target.files && event.target.files[0]){
      this.foto = event.target.files[0]

      const formData = new FormData
      formData.append('foto',this.foto)

      const nome:string = this.professor.pro_nome + "-" + event.target.files[0].name
      console.log(event.target.files[0].name)


      //http://localhost:8080/escola/send/22?nome=teste34
      this.http.post(`http://localhost:8080/escola/send/${this.idProfessorCadastrado}?nome=${nome}`,formData).subscribe({
        next: () => {console.log("Deu certo")
                         }
      })
      alert("Foto anexada ao Professor!")
      //this.router.navigate(['/professor/listaProfessor'])
      console.log(this.professor.pro_nome)
      console.log(this.professor.pro_foto)

    }

  }
}
