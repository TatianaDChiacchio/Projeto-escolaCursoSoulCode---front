import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Boleto } from 'src/app/models/boetoModel';
import { BoletoService } from 'src/app/servicos/boleto.service';

@Component({
  selector: 'app-edicao-boleto',
  templateUrl: './edicao-boleto.component.html',
  styleUrls: ['./edicao-boleto.component.css']
})
export class EdicaoBoletoComponent implements OnInit {

  codigo:any
  ra_aluno:any

  statusEscolhidoNoSelect:any

  statusParaEscolha:string[] = []

  boleto:Boleto ={
    codigo:'',
    bo_descricao:'',
    bo_dataVencimento:'',
    bo_status:'',
    bo_valor:0
  }

  constructor(private boletoService:BoletoService,
              private route:ActivatedRoute,
              private router:Router) { }



  ngOnInit(): void {

    this.codigo = this.route.snapshot.paramMap.get('codigo')
    this.ra_aluno = this.route.snapshot.paramMap.get('ra_aluno')
    this.statusParaEscolha = ['RECEBIDO','CANCELADO','PENDENTE']
    this.mostrarBoleto()

  }

  mostrarBoleto(){
    this.boletoService.buscarUmBoleto(this.codigo).subscribe(resultado =>{
      this.boleto = resultado
      this.boleto.bo_status = resultado.bo_status
    })
  }

  editarBoleto(){
    this.boletoService.editarBoleto(this.boleto,this.codigo, this.ra_aluno).subscribe({
      complete: () => {alert("boleto alterado com sucesso")
                      this.router.navigate([`/boleto/listaPorAluno/${this.ra_aluno}`])},
      error: () => {alert("Erro: Algo sai errado - boleto não editado")}
    })
  }

  statusEscolhido(){
    console.log(this.statusEscolhidoNoSelect)
    this.boleto.bo_status = this.statusEscolhidoNoSelect

  }

}
