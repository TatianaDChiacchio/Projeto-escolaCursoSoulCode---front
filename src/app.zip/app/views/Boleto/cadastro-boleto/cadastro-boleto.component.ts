import { ActivatedRoute, Router } from '@angular/router';
import { BoletoService } from './../../../servicos/boleto.service';
import { Component, OnInit } from '@angular/core';
import { Boleto } from 'src/app/models/boetoModel';
import { Status } from 'src/app/models/statusModel';

@Component({
  selector: 'app-cadastro-boleto',
  templateUrl: './cadastro-boleto.component.html',
  styleUrls: ['./cadastro-boleto.component.css']
})
export class CadastroBoletoComponent implements OnInit {

  ra_aluno:any

  statusEscolhidoNoSelect:any

  statusParaEscolha:string[] = []

  boleto:Boleto ={
    codigo:'',
    bo_descricao:'',
    bo_dataVencimento:'',
    bo_status:'',
    bo_valor:0
  }

  constructor(private boletoService:BoletoService,
              private route:ActivatedRoute,
              private router:Router) { }



  ngOnInit(): void {

    this.ra_aluno = this.route.snapshot.paramMap.get('ra_aluno')
    this.statusParaEscolha = ['RECEBIDO','CANCELADO','PENDENTE']
  }

  cadastrarBoleto(){
    this.boletoService.cadastrarBoleto(this.boleto,this.ra_aluno).subscribe({
      complete: () => {alert("boleto cadastrado com sucesso")
                      this.router.navigate([`/boleto/listaPorAluno/${this.ra_aluno}`])},
      error: () => {alert("Erro: Algo sai errado - boleto não cadastrado")}
    })
  }

  statusEscolhido(){
    console.log(this.statusEscolhidoNoSelect)
    this.boleto.bo_status = this.statusEscolhidoNoSelect

  }

}
