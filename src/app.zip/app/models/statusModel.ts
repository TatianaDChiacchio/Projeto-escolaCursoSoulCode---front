export interface Status{
  PENDENTE:string,
  CANCELADO:string,
  RECEBIDO:string

}
