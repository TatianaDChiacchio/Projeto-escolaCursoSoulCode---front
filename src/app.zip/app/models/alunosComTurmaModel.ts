export interface AlunosComTurma{
  ra_aluno?:any,
  al_nome:string,
  al_cidade: string,
  al_responsavel: string
  tu_nome:String
  tu_descricao:String
}
