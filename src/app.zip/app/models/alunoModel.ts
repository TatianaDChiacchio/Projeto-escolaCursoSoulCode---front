export interface Aluno{
  ra_aluno?:any,
  al_nome:string,
  al_cidade: string,
  al_responsavel: string

}
