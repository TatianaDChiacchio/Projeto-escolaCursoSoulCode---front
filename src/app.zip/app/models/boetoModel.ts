export interface Boleto{
  codigo?:any
  bo_descricao:String
  bo_dataVencimento:any
  bo_valor:any
  bo_status:string

}
