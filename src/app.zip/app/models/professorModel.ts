export interface Professor{

  id_professor?:any
  pro_nome:String
  pro_formacao:String
  pro_foto:String
}
