export interface AlunoComTurma{
  ra_aluno:'',
  al_nome:'',
  al_cidade: '',
  al_responsavel: '',
  tu_nome:'',
  tu_descricao:''

}
