export interface Turma{

  id_turma?:any
  tu_nome:String
  tu_descricao:String
}
